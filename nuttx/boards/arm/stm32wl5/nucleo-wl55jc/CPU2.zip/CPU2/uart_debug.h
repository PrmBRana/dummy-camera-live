#ifndef UART_DEBUG_H
#define UART_DEBUG_H

#include <stdint.h>

void uart2_init(void);

void uart2_putc(char c);

void uart2_puts(const char *s);

void uart2_printf(const char *fmt, ...);

/*
 * Non-blocking receive: returns 1 and fills *out_byte if a byte has
 * arrived, returns 0 immediately if nothing is waiting. Safe to poll
 * from a tight main loop. Requires uart2_init() to have been called
 * (which now also enables the receiver and configures PA3 as
 * USART2_RX).
 */
int uart2_try_getc(uint8_t *out_byte);

#endif