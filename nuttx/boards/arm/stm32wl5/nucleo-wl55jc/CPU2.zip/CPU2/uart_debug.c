#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>

#include "uart_debug.h"

/*
 * =====================================================================
 * WHAT CHANGED FROM THE PREVIOUS REVISION (root cause of "nothing
 * prints on the ground station")
 * =====================================================================
 * The NUCLEO-WL55JC1's ST-Link Virtual COM Port is wired to LPUART1
 * on PA2 (TX) / PA3 (RX) — NOT USART2. This is specific to this board
 * (confirmed in ST's UM2592 Nucleo-64 user manual, table of solder
 * bridges: "Communication between the target STM32WL and the
 * STLINK-V3E MCU is enabled on LPUART1 to support the Virtual COM
 * port"). USART2 exists on the chip and even shares the PA2/PA3 pin
 * numbers in some other configs, but on THIS board those physical
 * pins are only muxed to LPUART1 (AF8) for the ST-Link path, not
 * USART2 (AF7). That's why every previous revision — all the way
 * back to the original beacon-only file — printed nothing: the code
 * was correctly written for USART2, on the wrong peripheral for this
 * board's VCOM wiring, so nothing physically reached the ST-Link chip
 * no matter how correct the rest of the logic was.
 *
 * This revision switches the driver to LPUART1:
 *  - Different peripheral base address (0x40008000, not USART2's
 *    0x40004400).
 *  - Different RCC enable register/bit: RCC_APB1ENR2 bit 0
 *    (LPUART1EN), not RCC_APB1ENR1 bit 17 (USART2EN).
 *  - PA2/PA3 now muxed to AF8 (LPUART1), not AF7 (USART2).
 *  - LPUART's BRR register uses a DIFFERENT formula than a normal
 *    USART: it's a 256x-oversampling divider (BRR = 256 * fck / baud),
 *    not the plain fck/baud divisor USART2 used. Reusing the old
 *    BRR=417 value here would have produced garbage output even with
 *    the right peripheral, since 417 was computed for the wrong
 *    formula entirely. For an assumed 48 MHz LPUART kernel clock at
 *    115200 baud: BRR = 256 * 48,000,000 / 115,200 ≈ 106667.
 *
 * ASSUMPTION: LPUART1's kernel clock source (RCC_CCIPR.LPUART1SEL) is
 * left at its reset default, which selects PCLK1 (APB1 clock). If
 * your clock tree runs APB1 at something other than 48 MHz, recompute
 * BRR accordingly (BRR = 256 * actual_fck_hz / baud) or output will
 * be garbled rather than silent.
 * =====================================================================
 */

#define RCC_AHB2ENR     (*(volatile uint32_t *)0x5800004C)
#define RCC_APB1ENR2    (*(volatile uint32_t *)0x5800005C)
#define RCC_APB1RSTR2   (*(volatile uint32_t *)0x5800003C)


#define GPIOA_MODER     (*(volatile uint32_t *)0x48000000)
#define GPIOA_OSPEEDR   (*(volatile uint32_t *)0x48000008)
#define GPIOA_PUPDR     (*(volatile uint32_t *)0x4800000C)
#define GPIOA_AFRL      (*(volatile uint32_t *)0x48000020)


#define LPUART1_BASE    0x40008000UL
#define LPUART1_CR1     (*(volatile uint32_t *)(LPUART1_BASE + 0x00))
#define LPUART1_BRR     (*(volatile uint32_t *)(LPUART1_BASE + 0x0C))
#define LPUART1_ISR     (*(volatile uint32_t *)(LPUART1_BASE + 0x1C))
#define LPUART1_RDR     (*(volatile uint32_t *)(LPUART1_BASE + 0x24))
#define LPUART1_TDR     (*(volatile uint32_t *)(LPUART1_BASE + 0x28))


#define USART_CR1_UE    (1<<0)
#define USART_CR1_RE    (1<<2)
#define USART_CR1_TE    (1<<3)

#define USART_ISR_RXNE  (1<<5)
#define USART_ISR_TXE   (1<<7)

/* 256x-oversampling divider for LPUART: BRR = 256 * fck / baud.
   Assumes a 48 MHz LPUART1 kernel clock (PCLK1) and 115200 baud. */
#define LPUART1_BRR_48MHZ_115200   106667u



void uart2_init(void)
{
    /* GPIOA clock */
    RCC_AHB2ENR |= (1<<0);

    /* LPUART1 clock enable + reset */
    RCC_APB1ENR2 |= (1<<0);

    RCC_APB1RSTR2 |= (1<<0);
    RCC_APB1RSTR2 &= ~(1<<0);



    /* PA2 = LPUART1 TX, PA3 = LPUART1 RX, both AF8 */

    GPIOA_MODER &= ~((3<<4) | (3<<6));
    GPIOA_MODER |= (2<<4) | (2<<6);

    GPIOA_AFRL &= ~((0xF<<8) | (0xF<<12));
    GPIOA_AFRL |= (8<<8) | (8<<12);

    GPIOA_OSPEEDR |= (3<<4) | (3<<6);

    GPIOA_PUPDR &= ~((3<<4) | (3<<6));
    /* Idle-high pull-up on the RX line so it doesn't float if nothing
       is driving it. */
    GPIOA_PUPDR |= (1<<6);



    LPUART1_BRR = LPUART1_BRR_48MHZ_115200;

    LPUART1_CR1 = USART_CR1_TE | USART_CR1_RE;

    LPUART1_CR1 |= USART_CR1_UE;

}



void uart2_putc(char c)
{

    while(!(LPUART1_ISR & USART_ISR_TXE));


    LPUART1_TDR=c;

}



void uart2_puts(const char *s)
{

    while(*s)
    {

        if(*s=='\n')
        {
            uart2_putc('\r');
        }


        uart2_putc(*s++);

    }

}



void uart2_printf(const char *fmt,...)
{

    char buf[128];

    va_list args;


    va_start(args,fmt);

    vsnprintf(
        buf,
        sizeof(buf),
        fmt,
        args
    );

    va_end(args);


    uart2_puts(buf);

}



int uart2_try_getc(uint8_t *out_byte)
{
    if (LPUART1_ISR & USART_ISR_RXNE)
    {
        *out_byte = (uint8_t)(LPUART1_RDR & 0xFF);
        return 1;
    }

    return 0;
}