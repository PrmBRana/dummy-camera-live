/******************************************************************************
 *
 *  S2S-2 CubeSat
 *  STM32WL55 Cortex-M0+
 *
 *  Continuous AX.25 Receiver
 *  CMD_REQUEST_BURST ->
 *      Send 50 AX.25 Beacon packets
 *      every 5 seconds
 *
 ******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

#include "stm32wlxx_hal.h"

#include "radio.h"
#include "subghz.h"
#include "radio_board_if.h"

#include "uart_debug.h"

#include "config.h"
#include "radio_app.h"
#include "protocol.h"

/*-------------------------------------------------------------*/
/* Configuration                                                */
/*-------------------------------------------------------------*/

#define MAX_PACKET_SIZE      330
#define BURST_PACKET_COUNT   50
#define BURST_INTERVAL_MS    5000

/*-------------------------------------------------------------*/
/* Buffers                                                      */
/*-------------------------------------------------------------*/

static uint8_t rxFrame[MAX_PACKET_SIZE];

static uint8_t payload[MAX_PACKET_SIZE];

static uint8_t txFrame[MAX_PACKET_SIZE];

static uint8_t txPayload[90] =
"Namaste Everyone! From Antarikchya Nepal. S2S-2 CubeSat Beacon Communication Test";

/*-------------------------------------------------------------*/
/* State Variables                                              */
/*-------------------------------------------------------------*/

static bool burstMode = false;

static uint8_t burstCounter = 0;

/*-------------------------------------------------------------*/

static void System_Startup(void);

static void ProcessReceivedPacket(void);

static void StartBurstTransmission(void);

static void SendNextBeacon(void);

/*-------------------------------------------------------------*/

int main(void)
{
    SystemInit();

    HAL_Init();

    uart2_init();

    uart2_puts("\r\n");
    uart2_puts("========================================\r\n");
    uart2_puts("      S2S-2 SATELLITE SOFTWARE\r\n");
    uart2_puts("========================================\r\n");

    System_Startup();

    uart2_puts("Satellite Ready\r\n");
    uart2_puts("Listening...\r\n");

    while (1)
    {
        if (!burstMode)
        {
            if (RadioApp_HasPacket())
            {
                ProcessReceivedPacket();
            }
        }
    }
}