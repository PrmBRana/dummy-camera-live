#include <string.h>
#include "ax25.h"
#include "crc16.h"


void AX25_EncodeAddress(
        uint8_t *address,
        const char *callsign,
        uint8_t ssid,
        bool last)
{
    uint8_t i;


    for(i=0;i<6;i++)
    {
        uint8_t c=' ';

        if(callsign[i] != '\0')
            c=callsign[i];

        address[i]=c<<1;
    }


    address[6]=0x60 | ((ssid & 0x0F)<<1);


    if(last)
        address[6]|=0x01;
}



uint16_t AX25_BuildFrame(
        uint8_t *frame,
        const char *destination,
        uint8_t destinationSSID,
        const char *source,
        uint8_t sourceSSID,
        const uint8_t *payload,
        uint16_t payloadLength)
{

    uint16_t index=0;


    /*
       AX25 Frame

       FLAG
       DEST
       SOURCE
       CONTROL
       PID
       DATA
       CRC
       FLAG

    */


    frame[index++]=AX25_FLAG;


    AX25_EncodeAddress(
            &frame[index],
            destination,
            destinationSSID,
            false);

    index+=7;



    AX25_EncodeAddress(
            &frame[index],
            source,
            sourceSSID,
            true);

    index+=7;



    frame[index++]=AX25_CONTROL_UI;


    frame[index++]=AX25_PID_NO_LAYER3;



    memcpy(
        &frame[index],
        payload,
        payloadLength);


    index+=payloadLength;



    uint16_t crc;


    /*
       CRC does NOT include flags
    */

    crc=CRC16_X25(
            &frame[1],
            index-1);



    frame[index++]=crc & 0xFF;

    frame[index++]=crc>>8;



    frame[index++]=AX25_FLAG;



    return index;
}

bool AX25_ParseFrame(
        const uint8_t *frame,
        uint16_t frameLength,
        uint8_t *payload,
        uint16_t *payloadLength)
{

    if(frameLength < 20)
        return false;


    if(frame[0] != AX25_FLAG)
        return false;


    if(frame[frameLength-1] != AX25_FLAG)
        return false;


    uint16_t crcReceived;

    crcReceived =
        frame[frameLength-3] |
        (frame[frameLength-2] << 8);



    uint16_t crcCalculated;

    crcCalculated =
        CRC16_X25(
            &frame[1],
            frameLength-4);



    if(crcReceived != crcCalculated)
        return false;



    /*
       Frame format:

       FLAG       1
       DEST       7
       SOURCE     7
       CONTROL    1
       PID        1
       PAYLOAD    N
       CRC        2
       FLAG       1

       Payload starts at byte 17
    */


    uint16_t start = 17;


    *payloadLength =
        frameLength - start - 3;



    memcpy(
        payload,
        &frame[start],
        *payloadLength);



    return true;
}