#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>
#include <stdbool.h>

uint16_t Protocol_CreatePacket(
        uint8_t *outFrame,
        const uint8_t *payload,
        uint16_t payloadLength);

bool Protocol_DecodePacket(
        uint8_t *frame,
        uint16_t frameLength,
        uint8_t *payload,
        uint16_t *payloadLength);

void Protocol_ProcessCommand(
        const uint8_t *command,
        uint16_t length,
        uint8_t *reply,
        uint16_t *replyLength);

#endif