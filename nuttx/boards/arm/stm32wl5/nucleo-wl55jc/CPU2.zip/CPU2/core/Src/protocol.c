#include <stdint.h>
#include <string.h>

#include "protocol.h"
#include "config.h"
#include "ax25.h"
#include "g3ruh.h"

/*----------------------------------------------------------*/
/* Create AX.25 + G3RUH packet */
/*----------------------------------------------------------*/
uint16_t Protocol_CreatePacket(
        uint8_t *outFrame,
        const uint8_t *payload,
        uint16_t payloadLength)
{
    uint16_t size;

    size = AX25_BuildFrame(
                outFrame,
                GS_CALLSIGN,
                GS_SSID,
                SAT_CALLSIGN,
                SAT_SSID,
                payload,
                payloadLength);

    /* Scramble everything except the AX.25 flags */
    G3RUH_ScrambleBuffer(
            &outFrame[1],
            size - 2);

    return size;
}

/*----------------------------------------------------------*/
/* Decode AX.25 + G3RUH packet */
/*----------------------------------------------------------*/
bool Protocol_DecodePacket(
        uint8_t *frame,
        uint16_t frameLength,
        uint8_t *payload,
        uint16_t *payloadLength)
{
    G3RUH_DescrambleBuffer(
            &frame[1],
            frameLength - 2);

    return AX25_ParseFrame(
                frame,
                frameLength,
                payload,
                payloadLength);
}

/*----------------------------------------------------------*/
/* Execute received command */
/*----------------------------------------------------------*/
void Protocol_ProcessCommand(
        const uint8_t *command,
        uint16_t length,
        uint8_t *reply,
        uint16_t *replyLength)
{
    *replyLength = 0;

    if(length == 0)
        return;

    switch(command[0])
    {
        case CMD_PING:

            reply[0] = CMD_ACK;
            *replyLength = 1;
            break;

        case CMD_STATUS:

            memcpy(reply,
                   "SATELLITE OK",
                   12);

            *replyLength = 12;
            break;

        case CMD_RESET:

            /* Remove reset for now */
            break;

        default:
            break;
    }
}