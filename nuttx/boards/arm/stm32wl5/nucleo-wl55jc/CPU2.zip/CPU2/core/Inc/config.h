#ifndef CONFIG_H
#define CONFIG_H

#include <stdint.h>
#include <stdbool.h>


/*=========================================================
    DEVICE ROLE
=========================================================*/

#define DEVICE_IS_SATELLITE
// #define DEVICE_IS_GROUND_STATION



/*=========================================================
    FREQUENCY
=========================================================*/

#define SATELLITE_TX_FREQ      435000000UL
#define SATELLITE_RX_FREQ      437375000UL

#define GS_TX_FREQ             SATELLITE_RX_FREQ
#define GS_RX_FREQ             SATELLITE_TX_FREQ



/*=========================================================
    RADIO
=========================================================*/

#define RADIO_POWER_DBM        22
#define RADIO_BITRATE          4800
#define RADIO_FDEV             5000
#define RADIO_BANDWIDTH        23400

#define RADIO_PREAMBLE_BITS    128

#define RADIO_SYNCWORD_LEN     4

#define RADIO_TX_TIMEOUT       3000

#define RADIO_RX_TIMEOUT       0

#define RADIO_MAX_PAYLOAD      255



/*=========================================================
    AX25
=========================================================*/

#define AX25_CONTROL           0x03
#define AX25_PID               0xF0

#define AX25_FLAG              0x7E

#define AX25_MAX_FRAME         255



/*=========================================================
    CALLSIGN
=========================================================*/

#define SAT_CALLSIGN           "NEPAL1"
#define SAT_SSID               0


#define GS_CALLSIGN            "GROUND"
#define GS_SSID                0



/*=========================================================
    BEACON
=========================================================*/

#define BEACON_PERIOD_MS       90000UL



/*=========================================================
    COMMAND
=========================================================*/

#define CMD_PING               0x01
#define CMD_STATUS             0x02
#define CMD_RESET              0x03
#define CMD_ACK                0xAA



/*=========================================================
    DEBUG
=========================================================*/

#define UART_BAUDRATE          115200

#define ENABLE_DEBUG_PRINT     1


#endif