#ifndef RADIO_APP_H
#define RADIO_APP_H

#include <stdint.h>
#include <stdbool.h>

void RadioApp_Init(void);

void RadioApp_StartRX(void);

void RadioApp_Send(
        uint8_t *buffer,
        uint16_t length);

bool RadioApp_HasPacket(void);

uint16_t RadioApp_GetPacket(
        uint8_t *buffer);

#endif