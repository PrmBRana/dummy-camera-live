#ifndef AX25_H
#define AX25_H

#include <stdint.h>
#include <stdbool.h>

#define AX25_FLAG              0x7E
#define AX25_CONTROL_UI        0x03
#define AX25_PID_NO_LAYER3     0xF0

#define AX25_ADDR_LEN          7
#define AX25_MAX_FRAME_SIZE    330

/* Build AX.25 frame */
uint16_t AX25_BuildFrame(
    uint8_t *frame,
    const char *destination,
    uint8_t destinationSSID,
    const char *source,
    uint8_t sourceSSID,
    const uint8_t *payload,
    uint16_t payloadLength);

/* Parse AX.25 frame */
bool AX25_ParseFrame(
    const uint8_t *frame,
    uint16_t frameLength,
    uint8_t *payload,
    uint16_t *payloadLength);

/* Encode AX.25 address */
void AX25_EncodeAddress(
    uint8_t *address,
    const char *callsign,
    uint8_t ssid,
    bool last);

/* Encode callsign into 7-byte AX.25 format */
void AX25_EncodeCallsign(
    const char *callsign,
    uint8_t ssid,
    bool last,
    uint8_t out[7]);

#endif