#include <string.h>

#include "radio.h"
#include "radio_app.h"

static volatile bool packetReady=false;

static uint8_t rxBuffer[330];
static uint16_t rxLength=0;

/*------------------------------------------------*/

static void OnTxDone(void)
{
    Radio.Rx(0);
}

static void OnTxTimeout(void)
{
    Radio.Rx(0);
}

static void OnRxTimeout(void)
{
    Radio.Rx(0);
}

static void OnRxError(void)
{
    Radio.Rx(0);
}

static void OnCadDone(bool detected)
{
}

/*------------------------------------------------*/

static void OnRxDone(
        uint8_t *payload,
        uint16_t size,
        int16_t rssi,
        int8_t snr)
{
    memcpy(rxBuffer,payload,size);

    rxLength=size;

    packetReady=true;

    Radio.Rx(0);
}

/*------------------------------------------------*/

RadioEvents_t RadioEvents=
{
    .TxDone=OnTxDone,
    .RxDone=OnRxDone,
    .TxTimeout=OnTxTimeout,
    .RxTimeout=OnRxTimeout,
    .RxError=OnRxError,
    .CadDone=OnCadDone
};

/*------------------------------------------------*/

void RadioApp_Init(void)
{
    Radio.Init(&RadioEvents);
}

/*------------------------------------------------*/

void RadioApp_StartRX(void)
{
    Radio.Rx(0);
}

/*------------------------------------------------*/

void RadioApp_Send(
        uint8_t *buffer,
        uint16_t length)
{
    Radio.Send(buffer,length);
}

/*------------------------------------------------*/

bool RadioApp_HasPacket(void)
{
    return packetReady;
}

/*------------------------------------------------*/

uint16_t RadioApp_GetPacket(
        uint8_t *buffer)
{
    packetReady=false;

    memcpy(buffer,rxBuffer,rxLength);

    return rxLength;
}