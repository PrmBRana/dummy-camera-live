#include "g3ruh.h"


static uint32_t state;



void G3RUH_Reset(void)
{
    state = G3RUH_INIT_STATE;
}




uint8_t G3RUH_ScrambleByte(uint8_t input)
{

    uint8_t output = 0;


    for(int i=0;i<8;i++)
    {

        uint8_t in_bit =
            (input>>(7-i)) & 0x01;


        uint8_t feedback =
            ((state>>16) ^
             (state>>11)) & 0x01;



        uint8_t out_bit =
            in_bit ^ feedback;



        state =
            ((state<<1)|out_bit)
            &0x1FFFF;



        output =
            (output<<1)|out_bit;

    }


    return output;
}





uint8_t G3RUH_DescrambleByte(uint8_t input)
{

    uint8_t output = 0;


    for(int i=0;i<8;i++)
    {

        uint8_t in_bit =
            (input>>(7-i)) & 0x01;



        uint8_t feedback =
            ((state>>16) ^
             (state>>11)) & 0x01;



        uint8_t out_bit =
            in_bit ^ feedback;



        state =
            ((state<<1)|in_bit)
            &0x1FFFF;



        output =
            (output<<1)|out_bit;

    }


    return output;
}






void G3RUH_ScrambleBuffer(
        uint8_t *buffer,
        uint16_t length)
{

    G3RUH_Reset();


    for(uint16_t i=0;i<length;i++)
    {
        buffer[i]=
            G3RUH_ScrambleByte(buffer[i]);
    }
}






void G3RUH_DescrambleBuffer(
        uint8_t *buffer,
        uint16_t length)
{

    G3RUH_Reset();


    for(uint16_t i=0;i<length;i++)
    {
        buffer[i]=
            G3RUH_DescrambleByte(buffer[i]);
    }
}