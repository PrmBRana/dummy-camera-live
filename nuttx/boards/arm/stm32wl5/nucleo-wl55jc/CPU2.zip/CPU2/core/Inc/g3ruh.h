#ifndef G3RUH_H
#define G3RUH_H

#include <stdint.h>


#define G3RUH_POLY_LENGTH    17
#define G3RUH_INIT_STATE     0x1FFFFU



void G3RUH_Reset(void);



uint8_t G3RUH_ScrambleByte(
        uint8_t data);



uint8_t G3RUH_DescrambleByte(
        uint8_t data);



void G3RUH_ScrambleBuffer(
        uint8_t *buffer,
        uint16_t length);



void G3RUH_DescrambleBuffer(
        uint8_t *buffer,
        uint16_t length);



#endif