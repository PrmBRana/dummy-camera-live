#include "crc16.h"


uint16_t CRC16_X25(
        const uint8_t *data,
        uint16_t length)
{

    uint16_t crc=0xFFFF;


    while(length--)
    {

        crc ^= *data++;


        for(uint8_t i=0;i<8;i++)
        {

            if(crc & 1)

                crc=(crc>>1)^0x8408;

            else

                crc>>=1;

        }

    }


    return ~crc;
}